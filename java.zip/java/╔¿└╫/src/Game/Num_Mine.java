package Game;

public class Num_Mine {
	Integer mark_mine;
	Integer mark_correct_mine;
	Integer sum_mine;
	Num_Mine(Integer rn,Integer sn,Integer n)
	{
		mark_mine=new Integer(rn);
		mark_correct_mine=new Integer(sn);
		sum_mine=new Integer(n);
 
	}
 
}

