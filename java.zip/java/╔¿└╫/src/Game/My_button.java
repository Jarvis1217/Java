package Game;

import java.awt.Button;
 
// @SuppressWarnings("serial")
public class My_button extends Button {
	 int x;
	 int y;
	 My_button()
	 {
		 super();
	 }
	 My_button(int a,int b)
	 {
		 super();
		 x=a;
		 y=b;
	 }
}
