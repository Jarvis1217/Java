/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



import java.io.File;
import java.io.IOException;
import javax.swing.filechooser.FileSystemView;

/**
 *
 * @author Administrator
 */


    class   PFileSystemView   extends   FileSystemView   {
  public   File   createNewFolder(File   containingDir)   throws   IOException   {
  return   null;
  }
  }


